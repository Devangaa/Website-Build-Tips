   __  __   __       __ _______  ________ 
  |  \|  \ |  \  _  |  \       \|        \
 _| ▓▓| ▓▓_| ▓▓ / \ | ▓▓ ▓▓▓▓▓▓▓\\▓▓▓▓▓▓▓▓
|   ▓▓  ▓▓ \ ▓▓/  ▓\| ▓▓ ▓▓__/ ▓▓  | ▓▓   
 \▓▓▓▓▓▓▓▓▓▓ ▓▓  ▓▓▓\ ▓▓ ▓▓    ▓▓  | ▓▓   
|   ▓▓  ▓▓ \ ▓▓ ▓▓\▓▓\▓▓ ▓▓▓▓▓▓▓\  | ▓▓   
 \▓▓▓▓▓▓▓▓▓▓ ▓▓▓▓  \▓▓▓▓ ▓▓__/ ▓▓  | ▓▓   
  | ▓▓| ▓▓ | ▓▓▓    \▓▓▓ ▓▓    ▓▓  | ▓▓   
   \▓▓ \▓▓  \▓▓      \▓▓\▓▓▓▓▓▓▓    \▓▓   
                                           
Perhatian !
Nyalakan internet sebelum membuka index.html karena tugas ini pakai fontawesome !
Gunakan scale 100% di desktop karena ini bukan responsive web !
Semua halaman website bisa dibuka, dan profil ada di menu about !
Salam WBT ! 
